import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a-exp-outofstock-window',
  templateUrl: './a-exp-outofstock-window.component.html',
  styleUrls: ['./a-exp-outofstock-window.component.css']
})
export class AExpOutofstockWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
