import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expired-window',
  templateUrl: './expired-window.component.html',
  styleUrls: ['./expired-window.component.css']
})
export class ExpiredWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
