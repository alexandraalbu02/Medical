import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verified-doctor-order-window',
  templateUrl: './verified-doctor-order-window.component.html',
  styleUrls: ['./verified-doctor-order-window.component.css']
})
export class VerifiedDoctorOrderWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
