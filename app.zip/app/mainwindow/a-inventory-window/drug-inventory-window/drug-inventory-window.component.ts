import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drug-inventory-window',
  templateUrl: './drug-inventory-window.component.html',
  styleUrls: ['./drug-inventory-window.component.css']
})
export class DrugInventoryWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
