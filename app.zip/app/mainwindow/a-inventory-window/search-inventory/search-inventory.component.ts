import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-inventory',
  templateUrl: './search-inventory.component.html',
  styleUrls: ['./search-inventory.component.css']
})
export class SearchInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
