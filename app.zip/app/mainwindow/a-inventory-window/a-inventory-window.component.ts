import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a-inventory-window',
  templateUrl: './a-inventory-window.component.html',
  styleUrls: ['./a-inventory-window.component.css']
})
export class AInventoryWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
