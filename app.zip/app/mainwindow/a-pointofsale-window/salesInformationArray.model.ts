export interface SalesInformationArray {
  name: string;
  quantity: string;
}
