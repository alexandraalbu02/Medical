import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-out-elements',
  templateUrl: './check-out-elements.component.html',
  styleUrls: ['./check-out-elements.component.css']
})
export class CheckOutElementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
