import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-supplier-window',
  templateUrl: './search-supplier-window.component.html',
  styleUrls: ['./search-supplier-window.component.css']
})
export class SearchSupplierWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
