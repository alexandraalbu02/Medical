import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a-suppliers-window',
  templateUrl: './a-suppliers-window.component.html',
  styleUrls: ['./a-suppliers-window.component.css']
})
export class ASuppliersWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
