import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainwindow',
  templateUrl: './mainwindow.component.html',
  styleUrls: ['./mainwindow.component.css']
})
export class MainwindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
